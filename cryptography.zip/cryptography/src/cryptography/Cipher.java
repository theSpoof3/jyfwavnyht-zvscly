package cryptography;

public class Cipher {
	/* cypher object
	 * 
	 */
	static String cipher;
	public Cipher(){
		for (int i = 1; i<=26; i++){
			
		}
	}
	public static void main(String[] args) {

	}

}
