package cryptography;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class StandardCryptogramSolver {
	public static String[] readFile() throws FileNotFoundException {
		//reads a file into an arraylist, converts it to an array, and returns it
		Scanner scan = new Scanner("wordlist (1).txt");
		ArrayList<String> a = new ArrayList<String>();
		while (scan.hasNextLine()) {
			a.add(scan.nextLine());
		}
		String[] q = new String[a.size()];

		// ArrayList to Array Conversion
		for (int i =0; i < a.size(); i++)
			q[i] = a.get(i);

		scan.close();
		System.out.println(q);
		return q;
	}

	public static ArrayList<ArrayList<Integer>> findDoubles(String word) {
		ArrayList<ArrayList<Integer>> a = new ArrayList<ArrayList<Integer>>(); //stores combination representing identical letters
		for (int i = 0; i < word.length()-1; i++) { //iterate through word
			char c = word.charAt(i); //just for making it faster
			for (int j = i; j < word.length(); j++) {
				if (word.charAt(j) == c) {
					ArrayList<Integer> q = new ArrayList<Integer>();//make elements for main arraylist
					q.add(i);
					q.add(j);
					a.add(q);
				}
			}
		}
		return a;
	}

	public static ArrayList<String> findCiphers(String word, String[] wordList) {
		ArrayList<ArrayList<Integer>> doubles = findDoubles(word);
		int wordLength = word.length(); //making it slightly faster
		ArrayList<char[]> ciphers = new ArrayList<char[]>(); //stores strings that match the criteria
		for (int i = 0; i < wordList.length; i++) {//iterate through word list (long, but I have no better schemes)
			char[] possibility = {'#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#'};
			if (wordList[i].length() == wordLength) {
				for (int j = 0; j < doubles.size(); j++) {
					if (wordList[i].charAt(doubles.get(j).get(0)) == wordList[i].charAt(doubles.get(j).get(1))) {//test if the doubles are in the right place
						if (word.charAt(doubles.get(j).get(0)) == 'A') {
							possibility[0] = wordList[i].charAt(doubles.get(j).get(0));
						} else if (word.charAt(doubles.get(j).get(0)) == 'B') {
							possibility[1] = wordList[i].charAt(doubles.get(j).get(0));
						} else if (word.charAt(doubles.get(j).get(0)) == 'C') {
							possibility[2] = wordList[i].charAt(doubles.get(j).get(0));
						} else if (word.charAt(doubles.get(j).get(0)) == 'D') {
							possibility[3] = wordList[i].charAt(doubles.get(j).get(0));
						} else if (word.charAt(doubles.get(j).get(0)) == 'E') {
							possibility[4] = wordList[i].charAt(doubles.get(j).get(0));
						} else if (word.charAt(doubles.get(j).get(0)) == 'F') {
							possibility[5] = wordList[i].charAt(doubles.get(j).get(0));
						} else if (word.charAt(doubles.get(j).get(0)) == 'G') {
							possibility[6] = wordList[i].charAt(doubles.get(j).get(0));
						} else if (word.charAt(doubles.get(j).get(0)) == 'H') {
							possibility[7] = wordList[i].charAt(doubles.get(j).get(0));
						} else if (word.charAt(doubles.get(j).get(0)) == 'I') {
							possibility[8] = wordList[i].charAt(doubles.get(j).get(0));
						} else if (word.charAt(doubles.get(j).get(0)) == 'J') {
							possibility[9] = wordList[i].charAt(doubles.get(j).get(0));
						} else if (word.charAt(doubles.get(j).get(0)) == 'K') {
							possibility[10] = wordList[i].charAt(doubles.get(j).get(0));
						} else if (word.charAt(doubles.get(j).get(0)) == 'L') {
							possibility[11] = wordList[i].charAt(doubles.get(j).get(0));
						} else if (word.charAt(doubles.get(j).get(0)) == 'M') {
							possibility[12] = wordList[i].charAt(doubles.get(j).get(0));
						} else if (word.charAt(doubles.get(j).get(0)) == 'N') {
							possibility[13] = wordList[i].charAt(doubles.get(j).get(0));
						} else if (word.charAt(doubles.get(j).get(0)) == 'O') {
							possibility[14] = wordList[i].charAt(doubles.get(j).get(0));
						} else if (word.charAt(doubles.get(j).get(0)) == 'P') {
							possibility[15] = wordList[i].charAt(doubles.get(j).get(0));
						} else if (word.charAt(doubles.get(j).get(0)) == 'Q') {
							possibility[16] = wordList[i].charAt(doubles.get(j).get(0));
						} else if (word.charAt(doubles.get(j).get(0)) == 'R') {
							possibility[17] = wordList[i].charAt(doubles.get(j).get(0));
						} else if (word.charAt(doubles.get(j).get(0)) == 'S') {
							possibility[18] = wordList[i].charAt(doubles.get(j).get(0));
						} else if (word.charAt(doubles.get(j).get(0)) == 'T') {
							possibility[19] = wordList[i].charAt(doubles.get(j).get(0));
						} else if (word.charAt(doubles.get(j).get(0)) == 'U') {
							possibility[20] = wordList[i].charAt(doubles.get(j).get(0));
						} else if (word.charAt(doubles.get(j).get(0)) == 'V') {
							possibility[21] = wordList[i].charAt(doubles.get(j).get(0));
						} else if (word.charAt(doubles.get(j).get(0)) == 'W') {
							possibility[22] = wordList[i].charAt(doubles.get(j).get(0));
						} else if (word.charAt(doubles.get(j).get(0)) == 'X') {
							possibility[23] = wordList[i].charAt(doubles.get(j).get(0));
						} else if (word.charAt(doubles.get(j).get(0)) == 'Y') {
							possibility[24] = wordList[i].charAt(doubles.get(j).get(0));
						} else if (word.charAt(doubles.get(j).get(0)) == 'Z') {
							possibility[25] = wordList[i].charAt(doubles.get(j).get(0));
						}
					}
				}
				ciphers.add(possibility);
			}
		}
		return toStringArrayList(ciphers); //conveerts to String arraylist instead arraylist of char arrays
	}

	/* initiates the recursive method eliminate options, creating a tree of possibilities
	 * ussually all branches should terminate leaving an ArrayList of one possibility.
	 * ends recursion when at last branch
	 */
	public static void combineCiphers(ArrayList<ArrayList<String>> cipherList, String cipher) {
		ArrayList<ArrayList<String>> ciphers = eliminateOptions(cipherList); 

		for (int i = 0; i <=ciphers.size()-1; i++){
			for (int k = 0; k < ciphers.get(i).size(); k++) {

				printCipher(cipher, ciphers.get(i).get(k));
			}
		}


	}

	/* takes arraylist of arraylist of Strings
	 * combines and eliminates each row
	 * left with an arraylist of one arraylist of one string (more than one is techically possible but highly unlikely
	 */

	public static void printCipher(String message, String cipher) {
		String abc="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String solved="";
		//fixing case for greater than alphabet length


		for(int i=0; i<message.length(); i++) {
			char letter=message.charAt(i); //picks next letter
			int y=message.indexOf(letter); //position of coded letter
			if (letter==" ".charAt(0)) {
				solved=solved+" ";

				continue;

			} else if(y!=-1){


				char codeletter=abc.charAt(y); //converts letter to code letter based on rotation

				solved=solved + codeletter;

			} else if(y==-1){
				solved+=letter;

			}

		}

		System.out.println(solved);
	}

	public static ArrayList<ArrayList<String>> eliminateOptions(ArrayList<ArrayList<String>> cipherList){
		//makes new arrayList and sets size to one less than cipher list
		ArrayList<ArrayList<String>> newList = cipherList;
		ArrayList<String> tempList = new ArrayList<String>();
		newList.remove(0); //gets rid of the first list bc/s it will get combined with the next

		for (String i: cipherList.get(0)){ //iterate first word possibilities
			for (String j: cipherList.get(1)){//iterate through next set of possibilities
				if (noWorky(i, j)==false){ //if the two ciphers work together
					tempList.add(combine(i, j));
				}
			}
		}
		
		newList.set(0, tempList);
		/*for (int k = 1; k<=cipherList.size()-1; k++){ //fills the rest of newlist with the remaining uncombined ciphers
			for (String n: cipherList.get(k)){
				newList.set(k, cipherList.get(k));
				//newList.get(k).add(n);
			}
		}*/

		newList=eliminateOptions(newList);
		return newList;
	}


	/* combines two cipher Strings into one cipher String
	 * 
	 */
	public static String combine(String word1, String word2) { 
		String str = "";
		for (int i =0; i<=word1.length()-1; i++){
			if (word1.charAt(i)=='#'){
				str+=word2.charAt(i);
			}
			else if (word2.charAt(i)=='#'){
				str+=word1.charAt(i);
			}	
		}
		return str;
	}
	/* takes arraylist of char arrays
	 * returns ArrayList of Strings
	 */
	public static ArrayList<String> toStringArrayList(ArrayList<char []> ciphers){ 
		ArrayList<String> newCiphers = new ArrayList<String>();
		for (char [] code: ciphers){
			newCiphers.add(new String(code));

		}

		for (String n: newCiphers){
			System.out.println(n);
		}
		return newCiphers;
	}

	public static boolean noWorky(String string_1, String string_2){
		for (int i = 0; i<= 26; i++) {
			for (int j = 0; j<= 26; j++) {
				if (string_1.charAt(i)!='#'&&string_1.charAt(i)!=string_2.charAt(j)) { //if the characters....you know what it does
					return false;

				}

			}

		}
		return true;
	}

	public static void main(String[] args) throws FileNotFoundException {

		String[] wordList = readFile();
		System.out.println(wordList);
		/*
		Scanner console = new Scanner (System.in);
		System.out.println("input cipher, you idiot: ");
		//ArrayList<ArrayList<Integer>> a = findDoubles(word);
		String cipher = console.nextLine();*/
		System.out.println("auto initializing cipher: ");
		String cipher = "DJMLWK YNIS DJSM NW ZTO PNSRF LG TJSF. LH LZ POSO OJGY, OVOSYENFY PNIRF FN LZ. EIZ LZ’G WNZ. LZ ZJMOG BJZLOWCO, LZ ZJMOG CNDDLZDOWZ, JWF LZ CNDOG PLZT BROWZY NH HJLRISO JRNWK ZTO PJY. ZTO SOJR ZOGZ LG WNZ PTOZTOS YNI JVNLF ZTLG HJLRISO, EOCJIGO YNI PNW’Z. LZ’G PTOZTOS YNI ROZ LZ TJSFOW NS GTJDO YNI LWZN LWJCZLNW, NS PTOZTOS YNI ROJSW HSND LZ; PTOZTOS YNI CTNNGO ZN BOSGOVOSO.";
		String originalCipher = cipher;
		System.out.println(cipher);
		long startTime = System.currentTimeMillis();

		String[] orgiginalCipherList = cipher.split(" ");

		for (String s : orgiginalCipherList) {
			s = removePunctuation(s);
			//System.out.println(s);
		}

		ArrayList<ArrayList<String>> cipherList = new ArrayList<ArrayList<String>>();
		for (int i = 0; i < orgiginalCipherList.length-1; i++) { //iterate through String [] of each word
			cipherList.add(findCiphers(orgiginalCipherList[i], wordList));
			for (String c : findCiphers(orgiginalCipherList[i], wordList)) {
				System.out.println(c); //prints all possible 26 char ciphers
			}
		}

		combineCiphers(cipherList, originalCipher);
		/*ArrayList<String> combinedList = combineCiphers(cipherList);
		for (String c : combinedList) {
			System.out.println(c);
		}*/
		long endTime = System.currentTimeMillis();
		System.out.println(endTime-startTime);
		//console.close();
	}


	public static String removePunctuation(String s) {
		String x = "";
		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) != ',' && s.charAt(i) != '.' && s.charAt(i) != ';' && s.charAt(i) != ':' && s.charAt(i) != '\'') {
				x+= s.charAt(i);
			}
		}
		return x;
	}
}


