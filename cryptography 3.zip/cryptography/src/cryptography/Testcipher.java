package cryptography;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Testcipher {
    public static String[] readFile() throws FileNotFoundException { //make this return array use to set gloal array
      	 //reads a file into an arraylist, converts it to an array, and returns it
      	 Scanner scan = new Scanner("wordlist.txt");
      	 ArrayList<String> a = new ArrayList<String>();
      	 while (scan.hasNextLine()) {
      		 a.add(scan.nextLine());
      	 }
      	 String[] q = new String[a.size()];
      	 
       	// ArrayList to Array Conversion
       	for (int i =0; i < a.size(); i++)
           	q[i] = a.get(i);
      	 scan.close();
      	 return q;
       }
	//build the list
	public static Arraylist get
	
	public static void main(){
		//ArrayList<ArrayList<String>> cipherlist;
		//System.out.print(CryptogramSolver.compareOptions(options, cipherlist));

	}
}
