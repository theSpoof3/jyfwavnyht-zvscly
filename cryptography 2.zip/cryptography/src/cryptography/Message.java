package cryptography;

public class Message {
	public message
}
